create table parking_slot
(
    id          int auto_increment
        primary key,
    is_occupied tinyint default 0 not null,
    is_banned   tinyint default 0 not null,
    length      float             not null,
    width       float             not null,
    height      float             not null,
    hardware_id int               null,
    price       float             null comment '定价小时',
    name        char(20)          null comment '停车位昵称',
    longitude   float             not null,
    latitude    float             not null,
    picture_url char(50)          null,
    field_id    int               not null,
    owner_id    int               not null,
    constraint parking_slot_parking_field_id_fk
        foreign key (field_id) references parking_field (id),
    constraint parking_slot_user_id_fk
        foreign key (owner_id) references user (id)
)DEFAULT CHARACTER SET = utf8;

INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (1, 0, 0, 100, 1100, 1100, 9, 10, '一号停车位', 45, 45, null, 2, 1);
INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (2, 0, 0, 10, 10, 10, 8, 10, '二号停车位', 45, 45, null, 2, 1);
INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (3, 0, 0, 9, 9, 9, 5, 9.88, '三号停车位', 45, 45, null, 2, 1);
INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (4, 0, 0, 9, 8, 8, 5, 9.99, '四号停车位', 30, 30, null, 2, 1);
INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (5, 0, 0, 2, 2, 2, 54, 50, 'p_1', 28, 30, null, 3, 2);
INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (6, 0, 0, 3, 3.1, 3.3, 55, 50, 'p_2', 28, 30, null, 3, 2);
INSERT INTO intelligence_parking.parking_slot (id, is_occupied, is_banned, length, width, height, hardware_id, price, name, longitude, latitude, picture_url, field_id, owner_id) VALUES (7, 0, 0, 4, 4, 4, 10001, 5, '位test', 45.02, 37.01, null, 2, 1);