create table car
(
    id           int auto_increment
        primary key,
    license      char(20)          not null,
    type         char(20)          null,
    length       float             null,
    width        float             null,
    height       float             null,
    color        char(20)          not null,
    user_id      int               null,
    verification tinyint default 1 null comment '0 not verify yet
1 pass verification',
    constraint car_license_uindex
        unique (license),
    constraint car_user_id_fk
        foreign key (user_id) references user (id)
)DEFAULT CHARACTER SET = utf8;

INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (2, '粤B000000', '123', 10, 10, 10, '其他', 1, 1);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (3, '粤B000001', '本田', 7, 7, 7, '其他', 2, 1);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (4, '粤A xxxxxx', null, 10.1, 10.1, 10.1, '其他', 1, 1);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (11, '粤A11111', null, 10.1, 10.1, 10.1, '其他', 3, 1);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (13, '浙B 588xbb', null, 7.01, 3, 1.7, '其他', 3, 1);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (14, '浙B 788xbb', null, 4.01, 3, 1.7, '其他', 3, 0);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (15, '浙A 123456', null, 0, 0, 0, '其他', 3, 0);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (16, '浙A 654321', null, 0, 0, 0, '其他', 3, 1);
INSERT INTO intelligence_parking.car (id, license, type, length, width, height, color, user_id, verification) VALUES (17, '沪A 654321', null, 0, 0, 0, '其他', 3, 1);