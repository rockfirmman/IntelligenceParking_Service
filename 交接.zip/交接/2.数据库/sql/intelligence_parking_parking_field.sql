create table parking_field
(
    id             int auto_increment
        primary key,
    is_banned      tinyint default 0 not null,
    name           char(20)          not null comment '停车场昵称',
    longitude      float             not null,
    latitude       float             not null,
    description    char(100)         null,
    picture_url    char(50)          null,
    coordinate_url char(50)          null
)DEFAULT CHARACTER SET = utf8;

INSERT INTO intelligence_parking.parking_field (id, is_banned, name, longitude, latitude, description, picture_url, coordinate_url) VALUES (1, 0, '散户用停车场', 45, 45, '非真实停车场', null, null);
INSERT INTO intelligence_parking.parking_field (id, is_banned, name, longitude, latitude, description, picture_url, coordinate_url) VALUES (2, 0, '南方科技大学荔园停车场', 36.4, 37, '荔园停车场Test', null, null);
INSERT INTO intelligence_parking.parking_field (id, is_banned, name, longitude, latitude, description, picture_url, coordinate_url) VALUES (3, 0, '智园停车场1', 45, 45, null, null, null);
INSERT INTO intelligence_parking.parking_field (id, is_banned, name, longitude, latitude, description, picture_url, coordinate_url) VALUES (5, 0, '深圳湾停车场XXX', 36.4444, 37.0778, 'Test', null, null);