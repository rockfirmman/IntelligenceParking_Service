create table user
(
    id               int auto_increment,
    username         char(15)          not null,
    is_frozed        tinyint default 1 null,
    password         char(15)          not null,
    is_login         tinyint default 0 null,
    phone            char(20)          null,
    email            char(50)          null,
    is_administrator tinyint default 0 not null,
    avatar           char(50)          null,
    account          char(50)          null,
    constraint user_account_uindex
        unique (username),
    constraint user_email_uindex
        unique (email),
    constraint user_id_uindex
        unique (id)
)DEFAULT CHARACTER SET = utf8;

alter table user
    add primary key (id);

INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (1, 'rockfirmman', 0, '123456', 0, null, null, 1, null, null);
INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (2, 'admin', 0, 'testmodi', 0, '19923354053', '111@qq.com', 1, null, 'test');
INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (3, 'aaa', 0, '111111', 0, '86585716', 'xxxxx@xx.xx.edu.cn', 0, 'aaa', null);
INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (4, 'test_user1', 0, '123456', 0, null, null, 0, null, null);
INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (7, 'common_user_1', 0, '123456', 0, '18888888888', null, 0, null, null);
INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (8, 'common_user_2', 0, '123456', 0, '18888888888', 'xxxxxx@xxx.com', 0, null, null);
INSERT INTO intelligence_parking.user (id, username, is_frozed, password, is_login, phone, email, is_administrator, avatar, account) VALUES (48, 'email_test_1', 0, '123456', 0, '18923354053', '1424602142@qq.com', 0, null, 'alibaba');