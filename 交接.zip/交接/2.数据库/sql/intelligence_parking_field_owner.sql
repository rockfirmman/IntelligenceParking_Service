create table field_owner
(
    field_id int not null,
    owner_id int not null,
    primary key (field_id, owner_id),
    constraint filed_owner_parkfield_id_fk
        foreign key (field_id) references parking_field (id),
    constraint filed_owner_user_id_fk
        foreign key (owner_id) references user (id)
)DEFAULT CHARACTER SET = utf8;

INSERT INTO intelligence_parking.field_owner (field_id, owner_id) VALUES (1, 1);
INSERT INTO intelligence_parking.field_owner (field_id, owner_id) VALUES (2, 1);
INSERT INTO intelligence_parking.field_owner (field_id, owner_id) VALUES (1, 2);
INSERT INTO intelligence_parking.field_owner (field_id, owner_id) VALUES (1, 3);