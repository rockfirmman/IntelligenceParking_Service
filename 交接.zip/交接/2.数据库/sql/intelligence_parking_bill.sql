create table bill
(
    id         int auto_increment
        primary key,
    car_id     int           not null,
    slot_id    int           not null,
    field_id   int           not null,
    payer_id   int           not null,
    owner_id   int           not null,
    start_time datetime      null,
    end_time   datetime      null,
    cost       float         null,
    state      int default 1 null,
    score      int           null comment '评分',
    comments   char(50)      null,
    constraint bill_car_id_fk
        foreign key (car_id) references car (id),
    constraint bill_parking_field_id_fk
        foreign key (field_id) references parking_field (id),
    constraint bill_parking_slot_id_fk
        foreign key (slot_id) references parking_slot (id),
    constraint bill_user_id_fk
        foreign key (owner_id) references user (id),
    constraint bill_user_id_fk_2
        foreign key (payer_id) references user (id)
)DEFAULT CHARACTER SET = utf8;

INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (2, 2, 1, 2, 2, 2, '2020-11-28 19:09:11', null, 1000, 1, 5, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (3, 2, 1, 2, 2, 2, '2020-11-28 19:09:18', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (4, 2, 1, 2, 2, 2, '2020-11-28 19:09:20', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (5, 2, 1, 2, 2, 2, '2020-11-28 19:09:20', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (6, 2, 1, 2, 2, 2, '2020-11-28 19:09:21', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (7, 2, 1, 2, 2, 2, '2020-11-28 19:09:22', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (8, 2, 1, 2, 2, 2, '2015-03-27 21:13:23', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (9, 2, 1, 2, 2, 2, '2015-03-27 00:00:00', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (10, 2, 1, 2, 2, 2, '2015-03-27 21:13:23', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (11, 2, 1, 2, 2, 2, '2019-03-27 21:13:23', '2019-03-28 21:13:23', 68.7, 0, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (12, 2, 1, 2, 2, 2, '2015-03-27 21:13:23', null, null, 1, null, null);
INSERT INTO intelligence_parking.bill (id, car_id, slot_id, field_id, payer_id, owner_id, start_time, end_time, cost, state, score, comments) VALUES (13, 2, 1, 2, 2, 2, '2016-07-06 09:39:58', '2016-07-06 09:39:58', 65.07, 2, 4, 'hhh');